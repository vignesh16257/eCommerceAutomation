import configparser

class ConfigReader:
    @staticmethod
    def get_base_url():
        config = configparser.ConfigParser()
        config.read('config.ini')
        return config.get('URLs', 'base_url')

    # Add methods for reading other configurations
