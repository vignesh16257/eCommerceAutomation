
from selenium.webdriver.common.by import By
from utilities.customLogger import LogGen

class RecommendationsPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_recommendations_page(self):
        self.logger.info("Navigating to the recommendations page.")


    def scroll_through_recommendations(self):
        self.logger.info("Scrolling through the recommendations.")
        self.driver.execute_script("window.scrollBy(0, 500)")

    def verify_recommendations_displayed(self):
        self.logger.info("Verifying recommendations are displayed.")
        return self.driver.find_element(By.CLASS_NAME, 'recommendationItem').is_displayed()
