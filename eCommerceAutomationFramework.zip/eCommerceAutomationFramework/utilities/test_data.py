# utils/test_data.py
class TestData:
    POSITIVE_USERNAME = "valid_user"
    POSITIVE_PASSWORD = "valid_password"
    INVALID_USERNAME = "invalid_user"
    INVALID_PASSWORD = "invalid_password"
    # Add more test data as needed
