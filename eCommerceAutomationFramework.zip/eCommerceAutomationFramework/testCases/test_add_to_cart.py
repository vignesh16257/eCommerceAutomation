import pytest
from selenium import webdriver
from pageObjects.ProductPage import ProductPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

@pytest.mark.addToCart
def test_add_to_cart():
    logger = LogGen.loggen()
    logger.info("Test case test_add_to_cart started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    product_page = ProductPage(driver)
    product_page.navigate_to_product_page()

    #Our main application code here

    driver.quit()
    logger.info("Test case test_add_to_cart completed")
