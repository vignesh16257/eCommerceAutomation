import pytest
from selenium import webdriver
from pageObjects.SearchPage import SearchPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

@pytest.mark.search
def test_search_product():
    logger = LogGen.loggen()
    logger.info("Test case test_search_product started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    search_page = SearchPage(driver)
    search_page.navigate_to_search_page()

    # Our main application code here

    driver.quit()
    logger.info("Test case test_search_product completed")



