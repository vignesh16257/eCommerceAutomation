# pageObjects/LoginPage.py
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utilities.customLogger import LogGen
from utils.read_properties import ReadConfig

class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_login_page(self):
        self.logger.info("Navigating to the login page.")
        self.driver.get(ReadConfig.get_application_url())

    def enter_username(self, username):
        self.logger.info("Entering username.")
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'username'))).send_keys(username)

    def enter_password(self, password):
        self.logger.info("Entering password.")
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'password'))).send_keys(password)

    def click_login_button(self):
        self.logger.info("Clicking the login button.")
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.ID, 'loginButton'))).click()

    def verify_login_success(self):
        self.logger.info("Verifying login success.")
        success_message = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.CLASS_NAME, 'successMessage')))
        return success_message.is_displayed()
