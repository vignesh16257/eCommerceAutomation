
from selenium.webdriver.common.by import By
from utilities.customLogger import LogGen

class CheckoutPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_checkout_page(self):
        self.logger.info("Navigating to the checkout page.")


    def verify_checkout_summary(self):
        self.logger.info("Verifying the checkout summary.")
        return self.driver.find_element(By.CLASS_NAME, 'checkoutSummary').is_displayed()

    def select_payment_method(self, payment_method):
        self.logger.info(f"Selecting payment method: {payment_method}.")
        self.driver.find_element(By.ID, f'{payment_method}Radio').click()

    def place_order(self):
        self.logger.info("Placing the order.")
        self.driver.find_element(By.ID, 'placeOrderButton').click()

    def verify_order_success(self):
        self.logger.info("Verifying order success.")
        return self.driver.find_element(By.CLASS_NAME, 'orderSuccessMessage').is_displayed()
