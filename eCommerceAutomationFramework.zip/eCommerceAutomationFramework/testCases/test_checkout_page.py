
import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from pageObjects.CartPage import CartPage
from pageObjects.CheckoutPage import CheckoutPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

@pytest.mark.checkout
def test_checkout_process():
    logger = LogGen.loggen()
    logger.info("Test case test_checkout_process started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    # Login
    login_page = LoginPage(driver)
    login_page.navigate_to_login_page()
    # Implement logic to perform login if needed

    # Add product to the cart
    cart_page = CartPage(driver)
    cart_page.navigate_to_cart_page()
    # Implement logic to add a product to the cart if needed
    cart_page.proceed_to_checkout()

    # Checkout Process
    checkout_page = CheckoutPage(driver)
    checkout_page.navigate_to_checkout_page()
    assert checkout_page.verify_checkout_summary()

    # Select payment method
    checkout_page.select_payment_method("creditCard")

    # Place Order
    checkout_page.place_order()
    assert checkout_page.verify_order_success()

    driver.quit()
    logger.info("Test case test_checkout_process completed")
