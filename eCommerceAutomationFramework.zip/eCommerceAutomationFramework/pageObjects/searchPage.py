
from selenium.webdriver.common.by import By
from utilities.customLogger import LogGen

class SearchPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_search_page(self):
        self.logger.info("Navigating to the search page.")


    def enter_search_query(self, query):
        self.logger.info(f"Entering search query: {query}")
        self.driver.find_element(By.ID, 'searchInput').send_keys(query)

    def click_search_button(self):
        self.logger.info("Clicking the search button.")
        self.driver.find_element(By.ID, 'searchButton').click()

    def verify_search_results(self):
        self.logger.info("Verifying search results.")
        return self.driver.find_element(By.CLASS_NAME, 'searchResult').is_displayed()
