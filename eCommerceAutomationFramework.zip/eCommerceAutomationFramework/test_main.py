import pytest

if __name__ == "__main__":
    # Add any setup or configuration logic here

    # Run all tests in the tests folder
    pytest.main(['-v', 'tests/'])

