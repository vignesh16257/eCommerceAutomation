import pytest
from selenium import webdriver
from pageObjects.RecommendationsPage import RecommendationsPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

@pytest.mark.recommendations
def test_view_recommendations():
    logger = LogGen.loggen()
    logger.info("Test case test_view_recommendations started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    recommendations_page = RecommendationsPage(driver)
    recommendations_page.navigate_to_recommendations_page()

    # Our main application code here

    driver.quit()
    logger.info("Test case test_view_recommendations completed")

