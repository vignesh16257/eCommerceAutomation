
from selenium.webdriver.common.by import By
from utilities.customLogger import LogGen

class CartPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_cart_page(self):
        self.logger.info("Navigating to the cart page.")
        pass

    def verify_cart_contains_product(self):
        self.logger.info("Verifying the cart contains the added product.")

        return self.driver.find_element(By.CLASS_NAME, 'cartProduct').is_displayed()

    def proceed_to_checkout(self):
        self.logger.info("Proceeding to checkout.")
        self.driver.find_element(By.ID, 'checkoutButton').click()

    def enter_shipping_address(self, address, city, zip_code):
        self.logger.info("Entering shipping address.")
        self.driver.find_element(By.ID, 'addressInput').send_keys(address)
        self.driver.find_element(By.ID, 'cityInput').send_keys(city)
        self.driver.find_element(By.ID, 'zipCodeInput').send_keys(zip_code)

    def place_order(self):
        self.logger.info("Placing the order.")
        self.driver.find_element(By.ID, 'placeOrderButton').click()

    def verify_order_success(self):
        self.logger.info("Verifying order success.")
        return self.driver.find_element(By.CLASS_NAME, 'orderSuccessMessage').is_displayed()
