import time
from selenium.webdriver.support.ui import Select

class AddCustomer:
    # Add customer Page
    # lnkCustomers_menu_xpath = #####
    # lnkCustomers_menuitem_xpath = #####
    # btnAddnew_xpath = #####
    # txtEmail_xpath = #####
    # txtPassword_xpath = #####
    # txtcustomerRoles_xpath = #####
    # lstitemAdministrators_xpath = #####
    # lstitemRegistered_xpath = #####
    # lstitemGuests_xpath = #####
    # lstitemVendors_xpath = #####
    # drpmgrOfVendor_xpath = #####
    # rdMaleGender_id = #####
    # rdFeMaleGender_id = #####
    # txtFirstName_xpath = #####
    # txtLastName_xpath = #####
    # txtDob_xpath = #####
    # txtCompanyName_xpath = #####
    # txtAdminContent_xpath = #####
    # btnSave_xpath = #####


    def __init__(self, driver):
        self.driver = driver

    def clickOnCustomersMenu(self):
        self.driver.find_element_by_xpath(self.lnkCustomers_menu_xpath).click()

    def clickOnCustomersMenuItem(self):
        self.driver.find_element_by_xpath(self.lnkCustomers_menuitem_xpath).click()

    def clickOnAddnew(self):
        self.driver.find_element_by_xpath(self.btnAddnew_xpath).click()

    def setEmail(self,email):
        self.driver.find_element_by_xpath(self.txtEmail_xpath).send_keys(email)

    def setPassword(self,password):
        self.driver.find_element_by_xpath(self.txtPassword_xpath).send_keys(password)

    def setCustomerRoles(self,role):
        pass

    def setManagerOfVendor(self,value):
        pass


    def setGender(self,gender):
        pass

    def setFirstName(self, fname):
        self.driver.find_element_by_xpath(self.txtFirstName_xpath).send_keys(fname)

    def setLastName(self, lname):
        self.driver.find_element_by_xpath(self.txtLastName_xpath).send_keys(lname)

    def setDob(self, dob):
        self.driver.find_element_by_xpath(self.txtDob_xpath).send_keys(dob)

    def setCompanyName(self, comname):
        self.driver.find_element_by_xpath(self.txtCompanyName_xpath).send_keys(comname)

    def setAdminContent(self, content):
        self.driver.find_element_by_xpath(self.txtAdminContent_xpath).send_keys(content)

    def clickOnSave(self):
        self.driver.find_element_by_xpath(self.btnSave_xpath).click()