import pytest
from selenium import webdriver
from pageObjects.PaymentPage import PaymentPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

@pytest.mark.payment
def test_complete_payment():
    logger = LogGen.loggen()
    logger.info("Test case test_complete_payment started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    payment_page = PaymentPage(driver)
    payment_page.navigate_to_payment_page()

    # Our main application code here

    driver.quit()
    logger.info("Test case test_complete_payment completed")
