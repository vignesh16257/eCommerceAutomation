import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from utils.test_data import TestData

@pytest.mark.login
def test_successful_login():
    logger = LogGen.loggen()
    logger.info("Test case test_successful_login started")

    driver = webdriver.Chrome(executable_path=ReadConfig.get_chromedriver_path())
    driver.get(ReadConfig.get_application_url())

    login_page = LoginPage(driver)
    login_page.navigate_to_login_page()
    login_page.enter_username(TestData.POSITIVE_USERNAME)
    login_page.enter_password(TestData.POSITIVE_PASSWORD)
    login_page.click_login_button()

    assert login_page.verify_login_success()

    driver.quit()
    logger.info("Test case test_successful_login completed")
