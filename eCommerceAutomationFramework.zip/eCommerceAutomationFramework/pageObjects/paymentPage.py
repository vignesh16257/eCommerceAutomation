
from selenium.webdriver.common.by import By
from utilities.customLogger import LogGen

class PaymentPage:
    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()

    def navigate_to_payment_page(self):
        self.logger.info("Navigating to the payment page.")


    def enter_payment_details(self, card_number, expiry_date, cvv):
        self.logger.info("Entering payment details.")
        self.driver.find_element(By.ID, 'cardNumberInput').send_keys(card_number)
        self.driver.find_element(By.ID, 'expiryDateInput').send_keys(expiry_date)
        self.driver.find_element(By.ID, 'cvvInput').send_keys(cvv)

    def click_complete_payment_button(self):
        self.logger.info("Clicking the 'Complete Payment' button.")
        self.driver.find_element(By.ID, 'completePaymentButton').click()

    def verify_payment_success(self):
        self.logger.info("Verifying payment success.")
        return self.driver.find_element(By.CLASS_NAME, 'paymentSuccessMessage').is_displayed()
